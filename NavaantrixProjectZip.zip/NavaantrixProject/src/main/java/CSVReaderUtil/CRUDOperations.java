package CSVReaderUtil;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class CRUDOperations {
    private final Connection connection;

    public CRUDOperations(Connection connection) {
        this.connection = connection;
    }

    // CREATE operation
    public void insertData(String tableName, List<String[]> data) throws SQLException {
        String query = "INSERT INTO " + tableName + " (column1, column2, column3) VALUES (?, ?, ?)";
        PreparedStatement stmt = connection.prepareStatement(query);

        for (String[] row : data) {
            stmt.setString(1, row[0]);
            stmt.setString(2, row[1]);
            stmt.setString(3, row[2]);
            stmt.addBatch();
        }
        stmt.executeBatch();
    }

    // READ operation
    public void readData(String tableName) throws SQLException {
        String query = "SELECT * FROM " + tableName;
        PreparedStatement stmt = connection.prepareStatement(query);
        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
            System.out.println("ID: " + rs.getInt(1) + ", Col1: " + rs.getString(2) + ", Col2: " + rs.getString(3));
        }
    }

    // UPDATE operation
    public void updateData(String tableName, int id, String[] newData) throws SQLException {
        String query = "UPDATE " + tableName + " SET column1 = ?, column2 = ?, column3 = ? WHERE id = ?";
        PreparedStatement stmt = connection.prepareStatement(query);
        stmt.setString(1, newData[0]);
        stmt.setString(2, newData[1]);
        stmt.setString(3, newData[2]);
        stmt.setInt(4, id);
        stmt.executeUpdate();
    }

    // DELETE operation
    public void deleteData(String tableName, int id) throws SQLException {
        String query = "DELETE FROM " + tableName + " WHERE id = ?";
        PreparedStatement stmt = connection.prepareStatement(query);
        stmt.setInt(1, id);
        stmt.executeUpdate();
    }
}

