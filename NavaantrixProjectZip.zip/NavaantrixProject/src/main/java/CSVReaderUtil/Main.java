package CSVReaderUtil;
import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvValidationException;

import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

 class CSVReaderUtil {
    public List<String[]> readCSV(String filePath) {
        List<String[]> records = new ArrayList<>();
        try (CSVReader csvReader = new CSVReader(new FileReader(filePath))) {
            String[] values;
            while ((values = csvReader.readNext()) != null) {
                records.add(values);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (CsvValidationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        return records;
    }
}

// Main class in the same package
public class Main {
    public static void main(String[] args) {
        CSVReaderUtil csvReaderUtil = new CSVReaderUtil();
        String filePath = "C:\\Users\\nikit\\eclipse-workspace\\NavaantrixProject\\data.csv";
        List<String[]> data = csvReaderUtil.readCSV(filePath);

        for (String[] row : data) {
            System.out.println(String.join(", ", row));
        }
    }
}

