package CSVReaderUtil;


import java.io.FileWriter;
import java.io.IOException;

public class CSVFileWriter {
    public static void main(String[] args) {
        // Define file path for CSV
    	System.out.println(System.getProperty("user.dir"));

        String csvFile = "data.csv";
        
        // Data to be written in CSV
        String[] header = {"id", "name", "age", "city"};
        String[][] data = {
            {"1", "John Doe", "28", "New York"},
            {"2", "Jane Smith", "35", "Los Angeles"},
            {"3", "Michael Johnson", "22", "Chicago"},
            {"4", "Emily Davis", "45", "Houston"}
        };
        
        try (FileWriter writer = new FileWriter(csvFile)) {
            // Write the header
            writer.append(String.join(",", header));
            writer.append("\n");
            
            // Write the data rows
            for (String[] row : data) {
                writer.append(String.join(",", row));
                writer.append("\n");
            }
            
            System.out.println("CSV file created successfully!");
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

